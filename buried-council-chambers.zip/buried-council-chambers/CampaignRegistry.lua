{
	["sidebar"] = "charsheet,note,image,table,story,quest,npc,battle,item,treasureparcel",
}